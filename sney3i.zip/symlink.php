<?php
symlink(__DIR__.'/public', __DIR__.'/snnnn/public');
echo "done";

// /home/u407287626/public_html/sney3i/