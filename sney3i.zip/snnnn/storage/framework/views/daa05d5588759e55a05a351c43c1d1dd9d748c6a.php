<?php $__env->startSection('main-content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Liste des reclamations</h5>
                        </div>

                    </div>
                </div>

                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">client</h6>
                                        </div>
                                    </th>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">proffesionnel</h6>
                                        </div>
                                    </th>



                                    <th colspan="6" class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">contenu</h6>
                                        </div>
                                    </th>

                                    <th  class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">status</h6>
                                        </div>
                                    </th>

                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">date du reclamation</h6>
                                        </div>
                                    </th>

                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Action</h6>
                                        </div>
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                              
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            <?php echo e($item->user_name); ?>

                                        </a>
                                    </td>
                                    <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            <?php echo e($item->proffessionel_name); ?>

                                        </a>
                                    </td>
                                    <td colspan="6" class="align-middle text-center">
                                                <?php echo e($item->content); ?>

                                    </td>

                                    <td  class="align-middle text-center">
                                                <?php echo e($item->status); ?>

                                    </td>

                                    <td  class="align-middle text-center">
                                                <?php echo e($item->created_at); ?>

                                    </td>

                                    <td class="align-middle text-center">
                                    <?php if($item->status == "pending"): ?>
                                        <form action="<?php echo e(route('reclamation.update')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="reclamation_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Resolu" name="status" class="btn bg-gradient-success" />
                                        </form>

                                        <form action="<?php echo e(route('reclamation.update')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="reclamation_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Non Resolu" name="status" class="btn bg-gradient-danger" />
                                        </form>


                                        <?php endif; ?>
                                  
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u407287626/public_html/sney3i/snnnn/resources/views/dashboard/feedback/reclamation.blade.php ENDPATH**/ ?>