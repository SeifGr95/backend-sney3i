<?php $__env->startSection('main-content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Liste des Professionnels</h5>
                        </div>

                        <div class="ms-md-3 pe-md-3 d-flex align-items-center">
                            <form>
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <button type="submit"><span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span></button>
                                    <input type="text" class="form-control" name="proffessionel_name" placeholder="nom du proffessionel..." onfocus="focused(this)" onfocusout="defocused(this)">
                                </div>

                            </form>
                        </div>
                    </div>
                    <?php if(auth()->user()->role == 'societe'): ?>
                    <button class="btn bg-gradient-primary" data-bs-toggle="modal" data-bs-target="#proffessionelModal">
                        Ajouter professionnel
                    </button>
                    <?php endif; ?>

                </div>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger border-left-danger" role="alert">
                    <ul class="pl-4 my-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if(session('success')): ?>
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">N°</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Société</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Nom du Professionnel</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Sexe</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">CIN</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Email</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Numéro téléphone</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Adresse</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Sociéte</h6>
                                        </div>
                                    </th>
                                    <th colspan="2" class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Actions</h6>
                                        </div>
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=0
                                ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php
                                $i++
                                ?>
                                <?php if($item->societe->valid == 1 ): ?>
                                <tr>
                                    <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            <?php echo e($i); ?>

                                        </a>
                                    </td>
                                    
                                     <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            <?php echo e($item->societe->name); ?>

                                        </a>
                                    </td>

                                    <td class="">
                                        <img src="<?php echo e(url('snnnn/public/proffessionel/'.$item->image)); ?>" style="height: 70px; width: 70px;" />
                                        <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?>

                                    </td>
                                    <td class="align-middle text-center"><?php echo e($item->gender); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->cin); ?></td>
                                    <td class="align-middle text-center"> <?php echo e($item->email); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->phone); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->adress); ?></td>
                                    <td class="align-middle text-center">
                                        <?php echo !empty($item->parent_name) ? $item->parent_name : 'personnel'; ?>

                                    </td>

                                    <td>
                                        <?php if($item->status == 'verified'): ?>
                              <?php if($item->valid): ?>
                                        <form action="<?php echo e(route('prof.geler')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="prof_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Geler" name="status" class="btn btn-warning" />
                                        </form>

                                        <?php else: ?>
                                        
                                          <form action="<?php echo e(route('prof.restore')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="prof_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Restore" name="status" class="btn bg-gradient-success" />
                                        </form>
                                      


                                        <?php endif; ?>
                                        <?php else: ?>
                                        <form action="<?php echo e(route('prof.verification')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="prof_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Accept" name="status" class="btn bg-gradient-success" />
                                        </form>

                                        <form action="<?php echo e(route('prof.verification')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="prof_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Reject" name="status" class="btn bg-gradient-danger" />
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(auth()->user()->role == 'societe'): ?>
                                    <td class="align-middle text-center">
                                        
                                            <form action="<?php echo e(route('prof.show', $item->id)); ?>" method="GET">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="prof_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Show" name="status" class="btn btn-info" />
                                        </form>
                                    </td>
                                 
                                    <td class="align-middle text-center">
                                       
                                        
                                         <button class="btn bg-gradient-success" data-bs-toggle="modal" data-bs-target="#professionelModal-<?php echo e($item->id); ?>">
                                        update
                                    </button>

                                    <button class="btn bg-gradient-primary" data-bs-toggle="modal" data-bs-target="#proffessionelCategoryModal-<?php echo e($item->id); ?>">
                                        ajouter category
                                    </button>
                                    </td>
                           
   <td> <form action="<?php echo e(route('prof.delete')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="prof_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Delete" name="status" class="btn bg-gradient-danger" />
                                        </form></td>

                                    <?php endif; ?>
                                </tr>
                                
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                     <?php echo e($items->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if(auth()->user()->role == 'societe'): ?>
    <!-- create category modal -->
    <div class="modal match-modal fade" id="proffessionelModal" tabindex="-1" aria-labelledby="categoryModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ajouter professionnel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('prof.store')); ?>" class="m-4" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Nom du professionnel
                        </label>
                        <input name="last_name" class="form-control" type="text" id="example-text-input">
                    </div>

                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Prénom du professionnel
                        </label>
                        <input name="first_name" class="form-control" type="text" id="example-text-input">
                    </div>

                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Sexe</label>
                        </br>
                        <input name="gender" type="radio" value="homme" id="example-text-input"> <label for="huey">Homme</label>
                        </br>
                        <input name="gender" type="radio" value="famme" id="example-text-input"> <label for="huey">Femme</label>

                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">CIN</label>
                        <input name="cin" class="form-control" type="text" id="example-text-input">
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Email</label>
                        <input name="email" class="form-control" type="email" id="example-text-input">
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Telephone</label>
                        <input name="phone" class="form-control" type="text" id="example-text-input">
                    </div>

                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Date du naissance</label>
                        <input name="birthday" class="form-control" type="date" id="example-text-input">
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Adresse</label>
                       <select class = "form-control" name = "adress" id = "adress" required>
                           <option disabled selected>Selctionner l'adresse..</option>
                           <?php $__currentLoopData = $liste_adresse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($data->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select> 
                        
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Photo</label>
                        <input name="picture" class="form-control" type="file" id="example-text-input">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn bg-gradient-primary">Creer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal match-modal fade" id="proffessionelCategoryModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="categoryModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Professionnel spécialité</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('prof_affect_category')); ?>" class="m-4" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                 <input hidden name="prof_id" value="<?php echo e($item->id); ?>"/>
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($category->name); ?></h5>
                    <div class="form-group">
                        <fieldset>
                            <?php $__currentLoopData = $category->sub_category_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cateogry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <input type="checkbox" id="scales" name="categorys[]" value="<?php echo e($sub_cateogry->id); ?>" 
                                   <?php $__currentLoopData = $item->professionel_cateogries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_cateogry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <?php echo e($sub_cateogry->id == "$item_cateogry->category_id" ? 'checked' :''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                          

                                <label for="scales"><?php echo e($sub_cateogry->name); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </fieldset>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn bg-gradient-primary">Creer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- update professionel modal -->
    <div class="modal match-modal fade" id="professionelModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="categoryModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modifier professionnel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('prof.update' , $item->id)); ?>" class="m-4" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Prénom</label>
                        <input name="first_name" class="form-control" type="text" value="<?php echo e($item->first_name); ?>">
                    </div>
       <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Nom</label>
                        <input name="last_name" class="form-control" type="text" value="<?php echo e($item->last_name); ?>">
                    </div>
                    
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Adresse</label>
                        <input name="adress" class="form-control" type="text" value="<?php echo e($item->adress); ?>">
                    </div>
                    
                       <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Sexe</label>
                        <input name="gender" class="form-control" type="text" value="<?php echo e($item->gender); ?>">
                    </div>
                    
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Numéro téléphone</label>
                        <input name="phone" class="form-control" type="text" value="<?php echo e($item->phone); ?>">
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Date du naissance</label>
                        <input name="birthday" class="form-control" type="text" value="<?php echo e($item->birthday); ?>">
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Email</label>
                        <input name="email" class="form-control" type="text" value="<?php echo e($item->email); ?>">
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">CIN</label>
                        <input name="cin" class="form-control" type="text" value="<?php echo e($item->cin); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Image</label>
                            <img src="<?php echo e(url('public/proffessionel/'.$item->image)); ?>" style="height: 70px; width: 70px;" />
                        <input name="picture" class="form-control" type="file">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn bg-gradient-primary">Modifier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u565310583/domains/epsrd.com/public_html/sney3i/snnnn/resources/views/dashboard/proffessionel/index.blade.php ENDPATH**/ ?>