<?php $__env->startSection('main-content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Liste des societés</h5>
                        </div>
                        <div class="ms-md-3 pe-md-3 d-flex align-items-center">
                            <form>
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <button type="submit"><span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span></button>
                                    <input type="text" class="form-control" name="company_name" placeholder="nom du societé..." onfocus="focused(this)" onfocusout="defocused(this)">
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger border-left-danger" role="alert">
                    <ul class="pl-4 my-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if(session('success')): ?>
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Societé ID</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Nom du sociéte</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Email</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Numéro téléphone</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Adresse</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Statuts</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">date d'inscription</h6>
                                        </div>
                                    </th>

                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Actions</h6>
                                        </div>
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=0
                                ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                $i++
                                ?>
                                <tr>
                                    <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            <?php echo e($i); ?>

                                        </a>
                                    </td>
                                    <td class="align-middle text-center"><?php echo e($item->name); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->email); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->phone); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->adress); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->status); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->created_at); ?></td>
                                    <td>
                                        <?php if($item->status == 'verified' || $item->status == 'rejected'): ?>
                                        
                                           <form action="<?php echo e(route('company.delete')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="company_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Delete" name="status" class="btn bg-gradient-danger" />
                                        </form>
                                        <?php if($item->valid): ?>
                                        <form action="<?php echo e(route('company.geler', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" value="Geler" name="status" class="btn bg-gradient-warning" />
                                        </form>


                                        <?php else: ?>
                                       <form action="<?php echo e(route('company.restore', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" value="Restore" name="status" class="btn bg-gradient-success" />
                                        </form>


                                        <?php endif; ?>
                                        <?php else: ?>
                                        <form action="<?php echo e(route('company.verification')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="company_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Accept" name="status" class="btn bg-gradient-success" />
                                        </form>

                                        <form action="<?php echo e(route('company.verification')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="company_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Reject" name="status" class="btn bg-gradient-danger" />
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($items->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u565310583/domains/epsrd.com/public_html/sney3i/snnnn/resources/views/dashboard/company/index.blade.php ENDPATH**/ ?>