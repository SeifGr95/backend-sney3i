<?php $__env->startSection('main-content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Liste des clients</h5>
                        </div>

                    </div>
                </div>

                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">CLIENT ID</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Nom</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Adress</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">sexe</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">email</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">telephone</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">cin</h6>
                                        </div>
                                    </th>

                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">date d'inscription</h6>
                                        </div>
                                    </th>
                                    <th>
                                    <h6 class="mb-0 text-sm">Action</h6>
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle text-center">
                                        <?php echo e($item->id); ?>

                                    </td>
                                    <td class="align-middle text-center"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->adress); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->gender); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->email); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->phone); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->cin); ?></td>
                                    <td class="align-middle text-center"><?php echo e($item->created_at); ?></td>
                                    <td>
                                        <?php if($item->status == 'verified'): ?>
                                        <?php if($item->deleted_at): ?>
                                        <form action="<?php echo e(route('client.restore')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="client_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Restore" name="status" class="btn bg-gradient-success" />
                                        </form>


                                        <?php else: ?>
                                        <form action="<?php echo e(route('client.delete')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="client_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Delete" name="status" class="btn bg-gradient-danger" />
                                        </form>


                                        <?php endif; ?>
                                        <?php else: ?>
                                        <form action="<?php echo e(route('client.verification')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="client_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Accept" name="status" class="btn bg-gradient-success" />
                                        </form>

                                        <form action="<?php echo e(route('client.verification')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input hidden type="text" name="client_id" value="<?php echo e($item->id); ?>" />
                                            <input type="submit" value="Reject" name="status" class="btn bg-gradient-danger" />
                                        </form>
                                        <?php endif; ?>
                                    </td>


                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u407287626/public_html/sney3i/snnnn/resources/views/dashboard/client/index.blade.php ENDPATH**/ ?>