<?php $__env->startSection('main-content'); ?>

          <!-- show professionel modal -->

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Professionnel <?php echo e($proffessionel->first_name); ?> <?php echo e($proffessionel->last_name); ?></h5>
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <div class="form-group">
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Addresse :<?php echo e($proffessionel->adress); ?></label>
                    </div>
                    
                       <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Sexe : <?php echo e($proffessionel->gender); ?></label>
                    </div>
                    
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Numéro téléphone : <?php echo e($proffessionel->phone); ?></label>
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Date de naissance : <?php echo e($proffessionel->birthday); ?></label>
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Email : <?php echo e($proffessionel->email); ?></label>
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">CIN : <?php echo e($proffessionel->cin); ?></label>
                    </div>
                    
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Image</label>
                            <img src="<?php echo e(url('snnnn/public/proffessionel/'.$proffessionel->image)); ?>" style="height: 70px; width: 70px;" />
                    </div>
                       <div class="modal-footer">
                       <form action="<?php echo e(route('prof')); ?>" method="GET">
                                                                  <button type="submit" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>

                                        </form>
                    </div>
            </div>
 
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u565310583/domains/epsrd.com/public_html/sney3i/snnnn/resources/views/dashboard/proffessionel/show.blade.php ENDPATH**/ ?>