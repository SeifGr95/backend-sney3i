<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class proffessionel extends Model
{
    use HasFactory , SoftDeletes;
    protected $table = 'professionnels';
    protected $fillable=["uid","first_name",
    "last_name",
    "email",
    "cin",
    "image",
    "adress",
    "password",
    "picture",
    "birthday",
    "phone","calls","sms"];
    public function rating()
    {
        return $this->hasMany('App\Models\Rating','professionel_id','id');
    }
     public function professionel_cateogries()
    {
        return $this->hasMany('App\Models\professionel_cateogry');
    }
     public function societe()
    {
        return $this->belongsTo(Admin::class, "parent_id","id");
    }
   
}
