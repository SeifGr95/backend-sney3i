<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\professionel_cateogry;
use App\Models\proffessionel;
use App\Models\subcategory;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Models\Adress;

class ProffessionelController extends Controller
{

    public function index(Request $request)
    {
          $profesionnels = array();
 
        if (auth()->user()->role == 'admin') {
            if($request->proffessionel_name){
                $proffessionel_name_list = User::where('first_name', 'like', "%{$request->proffessionel_name}%")->pluck('id');
             }
            $items = proffessionel::withTrashed()->where('deleted_at', Null)->with('societe')->when($request->proffessionel_name, function ($query, $proffessionel_name ) {
                return $query->where('first_name', 'like', "%{$proffessionel_name}%")->orWhereIn('parent_id' ,  User::where('name', 'like', "%{$proffessionel_name}%")->pluck('id'))
                ->OrWhere('last_name', 'like', "%{$proffessionel_name}%")->orWhereIn('parent_id' ,  User::where('name', 'like', "%{$proffessionel_name}%")->pluck('id'));
            }, function ($query) {
                return $query->orderBy('status' , 'asc')
                ->orderBy('created_at' , 'desc');
            })->paginate(20);
        } else if (auth()->user()->role == 'societe') {
           /* $items = proffessionel::withTrashed()->where('deleted_at', Null)->with('professionel_cateogries')->orderBy('status', 'asc')
                ->where('parent_id', auth()->user()->id)
                ->orderBy('created_at', 'desc')
                ->get(); */
                
        $items = proffessionel::withTrashed()->where('deleted_at', Null)->with('professionel_cateogries')->with('societe')->where('parent_id', auth()->user()->id)->when($request->proffessionel_name, function ($query, $proffessionel_name ) {
                return $query->where('first_name', 'like', "%{$proffessionel_name}%")
                ->OrWhere('last_name', 'like', "%{$proffessionel_name}%");
            }, function ($query) {
                return $query->orderBy('status' , 'asc')
                ->orderBy('created_at' , 'desc');
            })->paginate(20);
        }
     /*   foreach($items as $item){
            if( $item->parent_id != null){
                $item->parent_name = User::where('id' , $item->parent_id)->value('name');
            }
        } */
        
    

//dd($items);
        $categorys = category::get();
        foreach ($categorys as $category) {
            $sub_category = subcategory::where('parent_id', $category->id)->get();
            $category->sub_category_items = $sub_category;
            $category->sub_category_count = count($sub_category);
        }
        
        $liste_adresse = $this->getListeAddresse();
         
        return view('dashboard.proffessionel.index', ['items' => $items , 'categorys' => $categorys, 'liste_adresse' => $liste_adresse]);
    }

    public function store (Request $request){
        $request->validate([
            'last_name' => 'required',
            'first_name' => 'required',
            'gender' => 'required',
            'cin' => 'required',
            'email' => 'required',
            'adress' => 'required',
            'picture' => 'required',
            'phone' => 'required',
            'birthday' => 'required',



        ]);
        $prof = new proffessionel();
        $prof->last_name = $request->input('last_name');
        $prof->first_name = $request->input('first_name');
        $prof->gender = $request->input('gender');
        $prof->cin = $request->input('cin');
        $prof->email = $request->input('email');
        $prof->adress = $request->input('adress');
        $prof->phone = $request->input('phone');
        $prof->status = 'verified';
        $prof->birthday = $request->input('birthday');
        $prof->parent_id = auth()->user()->id;


        $prof->password = 'NO LOGIN';
        if ($request->file('picture')) {
            $file = $request->file('picture');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('proffessionel'), $filename);
            $prof->image = $filename;
        }
        $prof->save();

        return redirect()->route('prof')->withSuccess('proffessionel added successfully.');
    }
    public function verification(Request $request)
    {
        $request->validate([

            'prof_id' => 'required',
            'status' => 'required'
        ]);
        $user = proffessionel::where('id', $request->prof_id)->first();
        if ($request->status == 'Accept') {
            $status = 'verified';
            Mail::send('email.confirmation', ["email" => $user->email, 'name' => $user->name, 'verified' => "true"], function ($message) use ($request, $user) {
                $message->to($user->email);
                $message->subject('Account Verification');
            });
        } else if ($request->status == 'Reject') {
            Mail::send('email.confirmation', ["email" => $user->email, 'name' => $user->name, 'verified' => "false"], function ($message) use ($request, $user) {
                $message->to($user->email);
                $message->subject('Account Verification');
            });
            $status = 'rejected';
        }
        proffessionel::where('id', $request->prof_id)->update(['status' => $status]);
        return redirect()->route('prof')->withSuccess('Proffessionnel ' . $status . ' successfully.');
    }

    public function geler(Request $request)
    {
        
                $request->validate([
            'prof_id' => 'required',
        ]);
             $proffessionel= proffessionel::findOrFail($request->prof_id);
//     dd(proffessionel);
     $proffessionel->valid = 0;
     $proffessionel->save();

      //  proffessionel::where('id', $request->prof_id)->delete();
        return redirect()->route('prof')->withSuccess('Proffessionnel geler successfully.');
    }

    public function restore(Request $request)
    {
        $request->validate([
            'prof_id' => 'required',
        ]);
     //   proffessionel::where('id', $request->prof_id)->restore();
     
                  $proffessionel= proffessionel::findOrFail($request->prof_id);
//     dd(proffessionel);
     $proffessionel->valid = 1;
     $proffessionel->save();

        return redirect()->route('prof')->withSuccess('Proffessionnel restored successfully.');
    }
    public function delete(Request $request)
    {
        $request->validate([
            'prof_id' => 'required',
        ]);
        proffessionel::where('id', $request->prof_id)->delete();
        return redirect()->route('prof')->withSuccess('Proffessionnel deleted successfully.');
    }

    public function affect_category(Request $request){
        foreach($request->categorys as $category){

            $professionel_cateogry = new professionel_cateogry();
            $professionel_cateogry->category_id = $category;
            $professionel_cateogry->proffessionel_id = $request->prof_id;
          
            $professionel_cateogry->save();
        }
        return redirect()->route('prof')->withSuccess('category affected successfully.');
    }
    
     public function update (Request $request, proffessionel $proffessionel){
         
        $proffessionel->last_name = $request->input('last_name');
        $proffessionel->first_name = $request->input('first_name');
        $proffessionel->gender = $request->input('gender');
        $proffessionel->cin = $request->input('cin');
        $proffessionel->email = $request->input('email');
        $proffessionel->adress = $request->input('adress');
        $proffessionel->phone = $request->input('phone');
        $proffessionel->status = 'verified';
        $proffessionel->birthday = $request->input('birthday');
        $proffessionel->parent_id = auth()->user()->id;


        $proffessionel->password = 'NO LOGIN';
        if ($request->file('picture')) {
            $file = $request->file('picture');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('proffessionel'), $filename);
            $proffessionel->image = $filename;
        }
        $proffessionel->save();

        return redirect()->route('prof')->withSuccess('proffessionel updated successfully.');
    }
    
     public function show ( proffessionel $proffessionel){
         
       

        return view('dashboard.proffessionel.show', ['proffessionel' => $proffessionel]);
    }
    
    public function getListeAddresse(){
        return Adress::all();
    }
    
}
