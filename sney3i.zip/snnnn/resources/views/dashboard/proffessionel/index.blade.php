@extends('dashboard.layouts.app')
@section('main-content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Liste des Professionnels</h5>
                        </div>

                        <div class="ms-md-3 pe-md-3 d-flex align-items-center">
                            <form>
                                @csrf
                                <div class="input-group">
                                    <button type="submit"><span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span></button>
                                    <input type="text" class="form-control" name="proffessionel_name" placeholder="nom du proffessionel..." onfocus="focused(this)" onfocusout="defocused(this)">
                                </div>

                            </form>
                        </div>
                    </div>
                    @if(auth()->user()->role == 'societe')
                    <button class="btn bg-gradient-primary" data-bs-toggle="modal" data-bs-target="#proffessionelModal">
                        Ajouter professionnel
                    </button>
                    @endif

                </div>
                @if ($errors->any())
                <div class="alert alert-danger border-left-danger" role="alert">
                    <ul class="pl-4 my-2">
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif

                @if (session('success'))
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                </div>
                @endif
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">N°</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Société</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Nom du Professionnel</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Sexe</h6>
                                        </div>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">CIN</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Email</h6>
                                        </div>
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Numéro téléphone</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Adresse</h6>
                                        </div>
                                    </th>
                                    <th class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Sociéte</h6>
                                        </div>
                                    </th>
                                    <th colspan="2" class="text-centerp text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        <div class="dalign-middle text-center">
                                            <h6 class="mb-0 text-sm">Actions</h6>
                                        </div>
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=0
                                ?>
                                @foreach($items as $item)
                                 <?php
                                $i++
                                ?>
                                @if($item->societe->valid == 1 )
                                <tr>
                                    <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            {{$i}}
                                        </a>
                                    </td>
                                    
                                     <td class="align-middle text-center">
                                        <a data-bs-toggle="modal" data-bs-target="#modalmatchlist">
                                            {{$item->societe->name}}
                                        </a>
                                    </td>

                                    <td class="">
                                        <img src="{{ url('snnnn/public/proffessionel/'.$item->image) }}" style="height: 70px; width: 70px;" />
                                        {{$item->first_name}} {{$item->last_name}}
                                    </td>
                                    <td class="align-middle text-center">{{$item->gender}}</td>
                                    <td class="align-middle text-center">{{$item->cin}}</td>
                                    <td class="align-middle text-center"> {{$item->email}}</td>
                                    <td class="align-middle text-center">{{$item->phone}}</td>
                                    <td class="align-middle text-center">{{$item->adress}}</td>
                                    <td class="align-middle text-center">
                                        {!! !empty($item->parent_name) ? $item->parent_name : 'personnel' !!}
                                    </td>

                                    <td>
                                        @if($item->status == 'verified')
                              @if($item->valid)
                                        <form action="{{route('prof.geler')}}" method="POST">
                                            @csrf
                                            <input hidden type="text" name="prof_id" value="{{$item->id}}" />
                                            <input type="submit" value="Geler" name="status" class="btn btn-warning" />
                                        </form>

                                        @else
                                        
                                          <form action="{{route('prof.restore')}}" method="POST">
                                            @csrf
                                            <input hidden type="text" name="prof_id" value="{{$item->id}}" />
                                            <input type="submit" value="Restore" name="status" class="btn bg-gradient-success" />
                                        </form>
                                      


                                        @endif
                                        @else
                                        <form action="{{route('prof.verification')}}" method="POST">
                                            @csrf
                                            <input hidden type="text" name="prof_id" value="{{$item->id}}" />
                                            <input type="submit" value="Accept" name="status" class="btn bg-gradient-success" />
                                        </form>

                                        <form action="{{route('prof.verification')}}" method="POST">
                                            @csrf
                                            <input hidden type="text" name="prof_id" value="{{$item->id}}" />
                                            <input type="submit" value="Reject" name="status" class="btn bg-gradient-danger" />
                                        </form>
                                        @endif
                                    </td>
                                    @if(auth()->user()->role == 'societe')
                                    <td class="align-middle text-center">
                                        
                                            <form action="{{route('prof.show', $item->id)}}" method="GET">
                                            @csrf
                                            <input hidden type="text" name="prof_id" value="{{$item->id}}" />
                                            <input type="submit" value="Show" name="status" class="btn btn-info" />
                                        </form>
                                    </td>
                                 
                                    <td class="align-middle text-center">
                                       
                                        
                                         <button class="btn bg-gradient-success" data-bs-toggle="modal" data-bs-target="#professionelModal-{{$item->id}}">
                                        update
                                    </button>

                                    <button class="btn bg-gradient-primary" data-bs-toggle="modal" data-bs-target="#proffessionelCategoryModal-{{$item->id}}">
                                        ajouter category
                                    </button>
                                    </td>
                           
   <td> <form action="{{route('prof.delete')}}" method="POST">
                                            @csrf
                                            <input hidden type="text" name="prof_id" value="{{$item->id}}" />
                                            <input type="submit" value="Delete" name="status" class="btn bg-gradient-danger" />
                                        </form></td>

                                    @endif
                                </tr>
                                
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                     {{$items->links()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if(auth()->user()->role == 'societe')
    <!-- create category modal -->
    <div class="modal match-modal fade" id="proffessionelModal" tabindex="-1" aria-labelledby="categoryModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ajouter professionnel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST" action="{{route('prof.store')}}" class="m-4" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Nom du professionnel
                        </label>
                        <input name="last_name" class="form-control" type="text" id="example-text-input">
                    </div>

                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Prénom du professionnel
                        </label>
                        <input name="first_name" class="form-control" type="text" id="example-text-input">
                    </div>

                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Sexe</label>
                        </br>
                        <input name="gender" type="radio" value="homme" id="example-text-input"> <label for="huey">Homme</label>
                        </br>
                        <input name="gender" type="radio" value="famme" id="example-text-input"> <label for="huey">Femme</label>

                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">CIN</label>
                        <input name="cin" class="form-control" type="text" id="example-text-input">
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Email</label>
                        <input name="email" class="form-control" type="email" id="example-text-input">
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Telephone</label>
                        <input name="phone" class="form-control" type="text" id="example-text-input">
                    </div>

                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Date du naissance</label>
                        <input name="birthday" class="form-control" type="date" id="example-text-input">
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Adresse</label>
                       <select class = "form-control" name = "adress" id = "adress" required>
                           <option disabled selected>Selctionner l'adresse..</option>
                           @foreach($liste_adresse as $data)
                            <option>{{$data->name}}</option>
                           @endforeach
                       </select> 
                        
                    </div>
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Photo</label>
                        <input name="picture" class="form-control" type="file" id="example-text-input">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn bg-gradient-primary">Creer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @foreach($items as $item)
    <div class="modal match-modal fade" id="proffessionelCategoryModal-{{$item->id}}" tabindex="-1" aria-labelledby="categoryModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Professionnel spécialité</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST" action="{{route('prof_affect_category')}}" class="m-4" enctype="multipart/form-data">
                    @csrf
                 <input hidden name="prof_id" value="{{$item->id}}"/>
                    @foreach($categorys as $category)
                    <h5 class="modal-title" id="exampleModalLabel">{{$category->name}}</h5>
                    <div class="form-group">
                        <fieldset>
                            @foreach($category->sub_category_items as $sub_cateogry)
                            <div>
                                <input type="checkbox" id="scales" name="categorys[]" value="{{$sub_cateogry->id}}" 
                                   @foreach($item->professionel_cateogries as $item_cateogry) 
                                {{ $sub_cateogry->id == "$item_cateogry->category_id" ? 'checked' :''}}  @endforeach>
                          

                                <label for="scales">{{$sub_cateogry->name}}</label>
                            </div>
                            @endforeach
                        </fieldset>
                    </div>
                    @endforeach

                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn bg-gradient-primary">Creer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endforeach
    
    
        @foreach($items as $item)
          <!-- update professionel modal -->
    <div class="modal match-modal fade" id="professionelModal-{{$item->id}}" tabindex="-1" aria-labelledby="categoryModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modifier professionnel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form method="POST" action="{{route('prof.update' , $item->id)}}" class="m-4" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Prénom</label>
                        <input name="first_name" class="form-control" type="text" value="{{$item->first_name}}">
                    </div>
       <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Nom</label>
                        <input name="last_name" class="form-control" type="text" value="{{$item->last_name}}">
                    </div>
                    
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Adresse</label>
                        <input name="adress" class="form-control" type="text" value="{{$item->adress}}">
                    </div>
                    
                       <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Sexe</label>
                        <input name="gender" class="form-control" type="text" value="{{$item->gender}}">
                    </div>
                    
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Numéro téléphone</label>
                        <input name="phone" class="form-control" type="text" value="{{$item->phone}}">
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Date du naissance</label>
                        <input name="birthday" class="form-control" type="text" value="{{$item->birthday}}">
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Email</label>
                        <input name="email" class="form-control" type="text" value="{{$item->email}}">
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">CIN</label>
                        <input name="cin" class="form-control" type="text" value="{{$item->cin}}">
                    </div>
                    
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Image</label>
                            <img src="{{ url('public/proffessionel/'.$item->image) }}" style="height: 70px; width: 70px;" />
                        <input name="picture" class="form-control" type="file">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn bg-gradient-primary">Modifier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
        @endforeach
    @endif
</div>
@endsection