@extends('dashboard.layouts.app')
@section('main-content')

          <!-- show professionel modal -->

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Professionnel {{$proffessionel->first_name}} {{$proffessionel->last_name}}</h5>
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <div class="form-group">
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Addresse :{{$proffessionel->adress}}</label>
                    </div>
                    
                       <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Sexe : {{$proffessionel->gender}}</label>
                    </div>
                    
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Numéro téléphone : {{$proffessionel->phone}}</label>
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Date de naissance : {{$proffessionel->birthday}}</label>
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Email : {{$proffessionel->email}}</label>
                    </div>
                           <div class="form-group">
                        <label for="example-text-input" class="form-control-label">CIN : {{$proffessionel->cin}}</label>
                    </div>
                    
                    <div class="form-group">
                        <label for="example-text-input" class="form-control-label">Image</label>
                            <img src="{{ url('snnnn/public/proffessionel/'.$proffessionel->image) }}" style="height: 70px; width: 70px;" />
                    </div>
                       <div class="modal-footer">
                       <form action="{{route('prof')}}" method="GET">
                                                                  <button type="submit" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fermer</button>

                                        </form>
                    </div>
            </div>
 
  

@endsection